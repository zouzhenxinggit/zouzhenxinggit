from distutils.core import setup

setup(name="zouGe", version="1.0", description="zouGe's module", author="zouGe", py_modules=['suba.a', 'suba.b', 'subb.c', 'subb.d'])

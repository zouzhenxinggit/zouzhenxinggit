#!/usr/bin/python3
#coding=utf-8

def fun_b():
	print("fun_b")
#!/usr/bin/python3
#coding=utf-8

def fun_c():
	print("fun_c")